from copy import deepcopy
from datetime import date, timedelta

import pandas as pd

from services.analytics.filter_engine import apply_ral_filters
from services.analytics.grouping_engine import calculate_grouped_metric
from services.semantics.vocabulary.metrics import calculate_metric


def _compatible_ral(query: dict, metric: str, start_date: str, end_date: str) -> dict:
    return {
        "ral_version": "2.0",
        "intent": "sales",
        "metric": metric,
        "time": {
            "type": "date_range",
            "start_date": start_date,
            "end_date": end_date,
        },
        "stores": list(query.get("stores", [])),
        "regions": [],
        "channels": list(query.get("channels", [])),
        "aggregators": [],
        "categories": [],
        "items": [],
        "grouping": {
            "enabled": bool(query.get("group_by")),
            "dimensions": list(query.get("group_by", [])),
        },
        "trend": {"enabled": False, "grain": None},
        "comparison": {
            "enabled": False,
            "from_start_date": None,
            "from_end_date": None,
            "to_start_date": None,
            "to_end_date": None,
        },
        "presentation": {"type": "text"},
        "understood_request": query.get("understood_request", "Business query"),
        "needs_clarification": False,
        "clarification_question": None,
    }


def _latest_data_date(data: dict) -> date | None:
    sales = data.get("sales")
    if sales is None or sales.empty or "Date" not in sales.columns:
        return None
    values = pd.to_datetime(sales["Date"], errors="coerce").dropna()
    if values.empty:
        return None
    return values.max().date()


def _effective_period(query: dict, data: dict) -> tuple[str, str]:
    time_value = query.get("time", {})
    start_text = time_value.get("start_date")
    end_text = time_value.get("end_date")
    if not start_text or not end_text:
        raise ValueError("I need a clear time period to run that analysis.")

    start = date.fromisoformat(start_text)
    end = date.fromisoformat(end_text)
    latest = _latest_data_date(data)

    if (
        latest is not None
        and time_value.get("type") in {"today", "this_week", "this_month", "this_quarter", "ytd"}
        and latest < end
        and latest >= start
    ):
        end = latest

    return start.isoformat(), end.isoformat()


def _comparison_period(start_text: str, end_text: str, comparison: str) -> tuple[str, str] | None:
    if comparison == "none":
        return None

    start = date.fromisoformat(start_text)
    end = date.fromisoformat(end_text)

    if comparison == "same_period_last_year":
        def shift(d: date) -> date:
            try:
                return d.replace(year=d.year - 1)
            except ValueError:
                return d.replace(year=d.year - 1, day=28)
        return shift(start).isoformat(), shift(end).isoformat()

    if comparison == "previous_period":
        span = (end - start).days + 1
        previous_end = start - timedelta(days=1)
        previous_start = previous_end - timedelta(days=span - 1)
        return previous_start.isoformat(), previous_end.isoformat()

    return None


def _growth(current: float, previous: float) -> float | None:
    if previous == 0:
        return None
    return (float(current) - float(previous)) / abs(float(previous)) * 100.0


def _calculate_metric_bundle(data: dict, query: dict, start_text: str, end_text: str) -> tuple[dict, int]:
    results = {}
    row_count = 0
    for metric in query["metrics"]:
        ral = _compatible_ral(query, metric, start_text, end_text)
        filtered = apply_ral_filters(data=data, ral_request=ral)
        row_count = max(row_count, len(filtered))
        results[metric] = calculate_metric(metric_name=metric, filtered_df=filtered)
    return results, row_count


def _calculate_grouped_bundle(data: dict, query: dict, start_text: str, end_text: str) -> list[dict]:
    merged: dict[tuple, dict] = {}
    dimensions = list(query.get("group_by", []))

    for metric in query["metrics"]:
        ral = _compatible_ral(query, metric, start_text, end_text)
        grouped = calculate_grouped_metric(
            filtered_sales=apply_ral_filters(data=data, ral_request=ral),
            data=data,
            ral_request=ral,
        )
        for row in grouped.get("rows", []):
            groups = row.get("groups", {})
            key = tuple(groups.get(dim, "") for dim in dimensions)
            target = merged.setdefault(key, {"groups": deepcopy(groups), "metrics": {}})
            target["metrics"][metric] = row.get("metric_value", 0)

    return list(merged.values())


def execute_business_query(data: dict, query: dict) -> dict:
    if query.get("needs_clarification"):
        return {
            "status": "clarification",
            "question": query.get("clarification_question") or "Could you clarify that request?",
        }

    if query.get("operation") not in {
        "retrieve", "compare", "summarize"
    }:
        return {"status": "not_yet_executable"}

    start_text, end_text = _effective_period(query, data)
    group_by = list(query.get("group_by", []))

    if group_by:
        rows = _calculate_grouped_bundle(data, query, start_text, end_text)
        return {
            "status": "ok",
            "result_type": "grouped",
            "period": {"start_date": start_text, "end_date": end_text},
            "metrics": list(query["metrics"]),
            "group_by": group_by,
            "rows": rows,
        }

    current, row_count = _calculate_metric_bundle(data, query, start_text, end_text)
    if row_count == 0:
        return {
            "status": "no_data",
            "period": {"start_date": start_text, "end_date": end_text},
        }

    comparison_name = query.get("comparison", "none")
    comparison_period = _comparison_period(start_text, end_text, comparison_name)
    comparison_values = None
    growth = None
    if comparison_period is not None:
        comparison_values, _ = _calculate_metric_bundle(
            data, query, comparison_period[0], comparison_period[1]
        )
        growth = {
            metric: _growth(current[metric], comparison_values[metric])
            for metric in query["metrics"]
        }

    return {
        "status": "ok",
        "result_type": "summary",
        "period": {"start_date": start_text, "end_date": end_text},
        "metrics": current,
        "comparison": {
            "type": comparison_name,
            "period": (
                {"start_date": comparison_period[0], "end_date": comparison_period[1]}
                if comparison_period
                else None
            ),
            "metrics": comparison_values,
            "growth_pct": growth,
        },
    }
